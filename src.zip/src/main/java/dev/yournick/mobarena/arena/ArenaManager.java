package dev.yournick.mobarena.arena;

import dev.yournick.mobarena.MobArenaPlugin;
import dev.yournick.mobarena.perk.PlayerPerk;
import dev.yournick.mobarena.player.PlayerProfile;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class ArenaManager {

    private final MobArenaPlugin plugin;

    private final Set<UUID> players = new HashSet<>();
    private final Set<LivingEntity> arenaMobs = new HashSet<>();

    private int wave = 0;
    private boolean running = false;

    private Location playerSpawn;
    private Location mobSpawn;
    private Location lobbySpawn;

    public ArenaManager(MobArenaPlugin plugin) {
        this.plugin = plugin;
        loadLocations();
    }
    public int getWave() {
        return wave;
    }

    public MobArenaPlugin getPlugin() { return plugin; }

    /* ===================== */
    /* JOIN / LEAVE */
    /* ===================== */

    public void join(Player player) {
        if (playerSpawn == null) {
            player.sendMessage(ChatColor.RED + "Ошибка: точка спавна игроков не задана!");
            return;
        }
        players.add(player.getUniqueId());
        player.teleport(playerSpawn);
        applyPlayerEffects(player);
        player.sendMessage(ChatColor.GREEN + "Ты вошёл на арену!");
    }

    public void leave(Player player) {
        if (lobbySpawn == null) {
            player.sendMessage(ChatColor.RED + "Ошибка: точка выхода из арены не задана!");
            return;
        }
        players.remove(player.getUniqueId());
        player.teleport(lobbySpawn);
        clearEffects(player);
        player.sendMessage(ChatColor.YELLOW + "Ты покинул арену.");
    }

    /* ===================== */
    /* WAVES */
    /* ===================== */

    public void startWave() {
        if (running) return;

        running = true;
        wave++;
        broadcast(ChatColor.GOLD + "⚔ Волна " + wave + " началась!");

        int mobCount = 3 + wave * 2;
        for (int i = 0; i < mobCount; i++) spawnMob();
    }

    private void spawnMob() {
        if (mobSpawn == null) return;

        Zombie zombie = (Zombie) mobSpawn.getWorld().spawnEntity(mobSpawn, org.bukkit.entity.EntityType.ZOMBIE);
        double multiplier = Math.pow(1.25, wave - 1);

        double baseHp = 20.0 * multiplier;
        double baseDamage = 3.0 * multiplier;

        zombie.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(baseHp);
        zombie.setHealth(baseHp);

        zombie.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE).setBaseValue(baseDamage);

        zombie.setCustomNameVisible(true);
        updateMobName(zombie);

        arenaMobs.add(zombie);
    }

    /* ===================== */
    /* MOB DEATH */
    /* ===================== */

    public void onMobDeath(LivingEntity mob, Player killer) {
        arenaMobs.remove(mob);

        if (killer != null) {
            PlayerProfile profile = plugin.getPlayerRepository().getProfile(killer);
            int gold = plugin.getConfig().getInt("rewards.gold_per_mob");
            profile.addGold(gold);
            killer.sendMessage(ChatColor.GOLD + "+ " + gold + " золота");
        }

        if (arenaMobs.isEmpty()) {
            running = false;
            broadcast(ChatColor.GREEN + "✔ Волна " + wave + " пройдена!");
        }
    }

    /* ===================== */
    /* PLAYER EFFECTS */
    /* ===================== */

    public void applyPlayerEffects(Player player) {
        clearEffects(player);
        PlayerProfile profile = plugin.getPlayerRepository().getProfile(player);
        if (profile == null) return;

        // Speed from upgrades
        int speedLevel = (int) profile.getBonusSpeed() - 1;
        if (speedLevel < 0) speedLevel = 0;

        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, speedLevel, false, false));

        // Apply perk effects
        if (profile.getPlayerPerk() != null) profile.getPlayerPerk().applyEffects(player);
    }

    private void clearEffects(Player player) {
        player.removePotionEffect(PotionEffectType.INCREASE_DAMAGE);
        player.removePotionEffect(PotionEffectType.SPEED);
    }

    /* ===================== */
    /* MOB NAME (HP) */
    /* ===================== */

    public void updateMobName(LivingEntity mob) {
        double hp = mob.getHealth();
        double max = mob.getAttribute(Attribute.GENERIC_MAX_HEALTH).getBaseValue();
        mob.setCustomName(ChatColor.RED + "❤ " + String.format("%.0f", hp) + "/" + String.format("%.0f", max));
    }

    public boolean isArenaMob(org.bukkit.entity.Entity entity) {
        return arenaMobs.contains(entity);
    }

    /* ===================== */
    /* LOCATIONS */
    /* ===================== */

    private void loadLocations() {
        playerSpawn = getLoc("arena.player-spawn");
        mobSpawn = getLoc("arena.mob-spawn");
        lobbySpawn = getLoc("arena.lobby");
    }

    private Location getLoc(String path) {
        String worldName = plugin.getConfig().getString(path + ".world");
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            plugin.getLogger().warning("Мир " + worldName + " не найден для " + path);
            return null;
        }
        double x = plugin.getConfig().getDouble(path + ".x");
        double y = plugin.getConfig().getDouble(path + ".y");
        double z = plugin.getConfig().getDouble(path + ".z");
        return new Location(world, x, y, z);
    }

    /* ===================== */
    /* UTILS */
    /* ===================== */

    private void broadcast(String msg) {
        for (UUID uuid : players) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) p.sendMessage(msg);
        }
    }
}
