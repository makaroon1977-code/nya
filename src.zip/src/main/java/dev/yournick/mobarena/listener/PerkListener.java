package dev.yournick.mobarena.listener;

import dev.yournick.mobarena.command.PerkSelectCommand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class PerkListener implements Listener {

    private final PerkSelectCommand command;

    public PerkListener(PerkSelectCommand command) {
        this.command = command;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        command.handleClick(e);
    }
}
