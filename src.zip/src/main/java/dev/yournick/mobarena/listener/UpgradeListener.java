package dev.yournick.mobarena.listener;

import dev.yournick.mobarena.command.UpgradeCommand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class UpgradeListener implements Listener {

    private final UpgradeCommand upgradeCommand;

    public UpgradeListener(UpgradeCommand upgradeCommand) {
        this.upgradeCommand = upgradeCommand;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        upgradeCommand.handleClick(e);
    }
}
