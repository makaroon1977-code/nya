package dev.yournick.mobarena.listener;

import dev.yournick.mobarena.arena.ArenaManager;
import dev.yournick.mobarena.player.PlayerProfile;
import dev.yournick.mobarena.perk.PlayerPerk;
import org.bukkit.Effect;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

public class MobDamageListener implements Listener {

    private final ArenaManager arena;

    public MobDamageListener(ArenaManager arena) {
        this.arena = arena;
    }

    @EventHandler
    public void onMobDamage(EntityDamageEvent e) {
        // =========================
        // Проверка игрока и перка "Ловкий"
        // =========================
        if (e.getEntity() instanceof Player) {
            Player player = (Player) e.getEntity();
            PlayerProfile profile = arena.getPlugin().getPlayerRepository().getProfile(player);
            if (profile != null) {
                PlayerPerk perk = profile.getPlayerPerk();
                if (perk != null && perk.tryDodge()) {
                    // Шанс уклонения
                    e.setCancelled(true);

                    // Эффект дыма у игрока
                    player.getWorld().playEffect(player.getLocation(), Effect.SMOKE, 1);
                    return;
                }
            }
        }

        // =========================
        // Проверка моба на арене
        // =========================
        if (!(e.getEntity() instanceof LivingEntity)) return;
        LivingEntity mob = (LivingEntity) e.getEntity();

        if (!arena.isArenaMob(mob)) return;

        // Обновляем HP-бар моба через 1 тик
        arena.getPlugin().getServer().getScheduler().runTaskLater(
                arena.getPlugin(),
                new Runnable() {
                    @Override
                    public void run() {
                        arena.updateMobName(mob);
                    }
                },
                1L
        );
    }
}
