package dev.yournick.mobarena.listener;

import dev.yournick.mobarena.command.ShopCommand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class ShopListener implements Listener {

    private final ShopCommand shopCommand;

    public ShopListener(ShopCommand shopCommand) {
        this.shopCommand = shopCommand;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        shopCommand.handleClick(e);
    }
}
