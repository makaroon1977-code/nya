package dev.yournick.mobarena.listener;

import dev.yournick.mobarena.MobArenaPlugin;
import dev.yournick.mobarena.player.PlayerRepository;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerJoinQuitListener implements Listener {

    private final PlayerRepository repository;

    public PlayerJoinQuitListener(PlayerRepository repository) {
        this.repository = repository;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        // создаём профиль при заходе
        repository.getProfile(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        // удаляем профиль из памяти (если не сохраняем в базу)
        repository.removeProfile(e.getPlayer());
    }
}
