package dev.yournick.mobarena.listener;

import dev.yournick.mobarena.arena.ArenaManager;
import dev.yournick.mobarena.player.PlayerProfile;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

public class MobDeathListener implements Listener {

    private final ArenaManager arena;

    public MobDeathListener(ArenaManager arena) {
        this.arena = arena;
    }

    @EventHandler
    public void onDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (!arena.isArenaMob(entity)) return;

        Player killer = entity.getKiller();
        if (killer == null) return;

        arena.onMobDeath(entity, killer);
    }
}
