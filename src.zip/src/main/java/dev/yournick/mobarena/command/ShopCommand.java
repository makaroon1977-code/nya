package dev.yournick.mobarena.command;

import dev.yournick.mobarena.MobArenaPlugin;
import dev.yournick.mobarena.player.PlayerProfile;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class ShopCommand implements CommandExecutor {

    private final MobArenaPlugin plugin;

    public ShopCommand(MobArenaPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        openShop((Player) sender);
        return true;
    }

    public void openShop(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, "§6Магазин арены");

        // Мечи
        addItem(inv, Material.WOOD_SWORD, "Деревянный меч", 50);
        addItem(inv, Material.STONE_SWORD, "Каменный меч", 100);
        addItem(inv, Material.IRON_SWORD, "Железный меч", 200);
        addItem(inv, Material.DIAMOND_SWORD, "Алмазный меч", 400);

        // Щит
        addItem(inv, Material.SHIELD, "Щит", 15);

        // Полные сеты брони (по шлему)
        addItem(inv, Material.LEATHER_HELMET, "Кожаная броня", 100);
        addItem(inv, Material.CHAINMAIL_HELMET, "Кольчужная броня", 200);
        addItem(inv, Material.IRON_HELMET, "Железная броня", 300);
        addItem(inv, Material.DIAMOND_HELMET, "Алмазная броня", 500);

        // Еда
        addItem(inv, Material.COOKED_BEEF, "Стейк x16", 30, 16);
        addItem(inv, Material.GOLDEN_APPLE, "Золотое яблоко", 20, 1);

        // Зелья
        addPotion(inv, false, 15); // Исцеление I
        addPotion(inv, true, 30);  // Исцеление II

        player.openInventory(inv);
    }

    private void addItem(Inventory inv, Material mat, String name, int cost) {
        addItem(inv, mat, name, cost, 1);
    }

    private void addItem(Inventory inv, Material mat, String name, int cost, int amount) {
        ItemStack item = new ItemStack(mat, amount);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.GREEN + name);
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.YELLOW + "Цена: " + cost + " золота");
            meta.setLore(lore);
            meta.setUnbreakable(true);
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
            item.setItemMeta(meta);
        }
        inv.addItem(item);
    }

    private void addPotion(Inventory inv, boolean strong, int cost) {
        ItemStack potion = new ItemStack(Material.POTION);
        ItemMeta meta = potion.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.LIGHT_PURPLE + (strong ? "Зелье исцеления II" : "Зелье исцеления I"));
            List<String> lore = new ArrayList<>();
            lore.add(ChatColor.YELLOW + "Цена: " + cost + " золота");
            meta.setLore(lore);
            potion.setItemMeta(meta);
        }
        potion.setDurability((short) (strong ? 16421 : 8261)); // 1.12.2 способ
        inv.addItem(potion);
    }

    // Обработка клика в магазине
    public void handleClick(InventoryClickEvent e) {
        if (!e.getView().getTitle().equals("§6Магазин арены")) return;
        e.setCancelled(true);

        Player player = (Player) e.getWhoClicked();
        PlayerProfile profile = plugin.getPlayerRepository().getProfile(player);
        if (profile == null) return;

        ItemStack clicked = e.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;

        int cost = getCostFromLore(clicked);
        if (profile.getGold() < cost) {
            player.sendMessage(ChatColor.RED + "Недостаточно золота!");
            return;
        }

        profile.removeGold(cost);

        // Если броня — выдаём полный сет
        if (isArmor(clicked.getType())) {
            giveFullArmorSet(player, clicked.getType());
            player.sendMessage(ChatColor.GREEN + "Вы купили полный сет брони за " + cost + " золота!");
        } else {
            // Мечи, щиты, еда, зелья
            ItemStack give = clicked.clone();
            if (give.getType() == Material.COOKED_BEEF) give.setAmount(16);
            else give.setAmount(1);
            player.getInventory().addItem(give);
            player.sendMessage(ChatColor.GREEN + "Вы купили " + clicked.getItemMeta().getDisplayName() + " за " + cost + " золота!");
        }

        player.closeInventory();
    }

    private boolean isArmor(Material mat) {
        return mat.name().endsWith("_HELMET") || mat.name().endsWith("_CHESTPLATE") ||
                mat.name().endsWith("_LEGGINGS") || mat.name().endsWith("_BOOTS");
    }

    private void giveFullArmorSet(Player player, Material helmet) {
        ItemStack h = new ItemStack(helmet);
        ItemStack c = new ItemStack(getChestFromHelmet(helmet));
        ItemStack l = new ItemStack(getLegsFromHelmet(helmet));
        ItemStack b = new ItemStack(getBootsFromHelmet(helmet));

        for (ItemStack i : new ItemStack[]{h, c, l, b}) {
            ItemMeta meta = i.getItemMeta();
            if (meta != null) {
                meta.setUnbreakable(true);
                meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
                i.setItemMeta(meta);
            }
        }

        player.getInventory().setHelmet(h);
        player.getInventory().setChestplate(c);
        player.getInventory().setLeggings(l);
        player.getInventory().setBoots(b);
    }

    private Material getChestFromHelmet(Material h) {
        switch (h) {
            case LEATHER_HELMET: return Material.LEATHER_CHESTPLATE;
            case CHAINMAIL_HELMET: return Material.CHAINMAIL_CHESTPLATE;
            case IRON_HELMET: return Material.IRON_CHESTPLATE;
            case DIAMOND_HELMET: return Material.DIAMOND_CHESTPLATE;
            default: return Material.AIR;
        }
    }
    private Material getLegsFromHelmet(Material h) {
        switch (h) {
            case LEATHER_HELMET: return Material.LEATHER_LEGGINGS;
            case CHAINMAIL_HELMET: return Material.CHAINMAIL_LEGGINGS;
            case IRON_HELMET: return Material.IRON_LEGGINGS;
            case DIAMOND_HELMET: return Material.DIAMOND_LEGGINGS;
            default: return Material.AIR;
        }
    }
    private Material getBootsFromHelmet(Material h) {
        switch (h) {
            case LEATHER_HELMET: return Material.LEATHER_BOOTS;
            case CHAINMAIL_HELMET: return Material.CHAINMAIL_BOOTS;
            case IRON_HELMET: return Material.IRON_BOOTS;
            case DIAMOND_HELMET: return Material.DIAMOND_BOOTS;
            default: return Material.AIR;
        }
    }

    private int getCostFromLore(ItemStack item) {
        if (!item.hasItemMeta() || item.getItemMeta().getLore() == null) return 0;
        String lore = item.getItemMeta().getLore().get(0);
        return Integer.parseInt(lore.replaceAll("[^0-9]", ""));
    }
}
