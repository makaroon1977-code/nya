package dev.yournick.mobarena.command;

import dev.yournick.mobarena.MobArenaPlugin;
import dev.yournick.mobarena.player.PlayerProfile;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class UpgradeCommand implements org.bukkit.command.CommandExecutor {

    private final MobArenaPlugin plugin;

    public UpgradeCommand(MobArenaPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(org.bukkit.command.CommandSender sender, org.bukkit.command.Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;
        openUpgradeGUI(player);
        return true;
    }

    public void openUpgradeGUI(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, "§6Апгрейды");
        PlayerProfile profile = plugin.getPlayerRepository().getProfile(player);
        if (profile == null) return;

        // Меч в руке
        ItemStack sword = player.getInventory().getItemInMainHand();
        if (sword != null && sword.getType() != Material.AIR) {
            addSwordUpgrade(inv, sword, Enchantment.DAMAGE_ALL, "Острота", profile, 5);
            addSwordUpgrade(inv, sword, Enchantment.SWEEPING_EDGE, "Разящий клинок", profile, 3);
        }

        // Броня
        addArmorUpgrade(inv, player.getInventory().getHelmet(), profile, "Шлем");
        addArmorUpgrade(inv, player.getInventory().getChestplate(), profile, "Нагрудник");
        addArmorUpgrade(inv, player.getInventory().getLeggings(), profile, "Штаны");
        addArmorUpgrade(inv, player.getInventory().getBoots(), profile, "Ботинки");

        player.openInventory(inv);
    }

    private void addSwordUpgrade(Inventory inv, ItemStack sword, Enchantment ench, String name, PlayerProfile profile, int maxLevel) {
        ItemStack item = sword.clone();
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        int current = meta.getEnchantLevel(ench);
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.YELLOW + name + ": " + current + "/" + maxLevel);
        int cost = getCost(ench, current);
        lore.add(ChatColor.GREEN + "Стоимость: " + cost + " золота");
        meta.setLore(lore);
        item.setItemMeta(meta);
        inv.addItem(item);
    }

    private void addArmorUpgrade(Inventory inv, ItemStack armor, PlayerProfile profile, String name) {
        if (armor == null || armor.getType() == Material.AIR) return;
        ItemStack item = armor.clone();
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        int current = meta.getEnchantLevel(Enchantment.PROTECTION_ENVIRONMENTAL);
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.YELLOW + "Защита " + name + ": " + current + "/5");
        lore.add(ChatColor.GREEN + "Стоимость: " + getArmorCost(current) + " золота");
        meta.setLore(lore);
        item.setItemMeta(meta);
        inv.addItem(item);
    }

    private int getCost(Enchantment ench, int level) {
        if (ench == Enchantment.DAMAGE_ALL) {
            switch (level) {
                case 0: return 100;
                case 1: return 200;
                case 2: return 400;
                case 3: return 500;
                case 4: return 1000;
            }
        } else if (ench == Enchantment.SWEEPING_EDGE) {
            switch (level) {
                case 0: return 300;
                case 1: return 500;
                case 2: return 1000;
            }
        }
        return -1;
    }

    private int getArmorCost(int level) {
        return 100;
    }

    public void handleClick(InventoryClickEvent e) {
        if (!e.getView().getTitle().equals("§6Апгрейды")) return;
        e.setCancelled(true);
        Player player = (Player) e.getWhoClicked();
        PlayerProfile profile = plugin.getPlayerRepository().getProfile(player);
        if (profile == null) return;

        ItemStack clicked = e.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;

        ItemMeta meta = clicked.getItemMeta();
        if (meta == null || !meta.hasLore()) return;

        List<String> lore = meta.getLore();
        int cost = Integer.parseInt(lore.get(1).replaceAll("[^0-9]", ""));
        if (profile.getGold() < cost) {
            player.sendMessage(ChatColor.RED + "Недостаточно золота!");
            return;
        }

        // Определяем тип апгрейда по лору
        String line0 = lore.get(0);
        if (line0.contains("Острота")) {
            int current = meta.getEnchantLevel(Enchantment.DAMAGE_ALL);
            if (current >= 5) {
                player.sendMessage(ChatColor.RED + "Максимальный уровень остроты достигнут!");
                return;
            }
            meta.addEnchant(Enchantment.DAMAGE_ALL, current + 1, true);
            clicked.setItemMeta(meta);
            player.getInventory().setItemInMainHand(clicked);
            profile.removeGold(cost);
            player.sendMessage(ChatColor.GREEN + "Острота увеличена до " + (current + 1));
        } else if (line0.contains("Разящий клинок")) {
            int current = meta.getEnchantLevel(Enchantment.SWEEPING_EDGE);
            if (current >= 3) {
                player.sendMessage(ChatColor.RED + "Максимальный уровень Разящего клинка достигнут!");
                return;
            }
            meta.addEnchant(Enchantment.SWEEPING_EDGE, current + 1, true);
            clicked.setItemMeta(meta);
            player.getInventory().setItemInMainHand(clicked);
            profile.removeGold(cost);
            player.sendMessage(ChatColor.GREEN + "Разящий клинок увеличен до " + (current + 1));
        } else if (line0.contains("Защита")) {
            int current = meta.getEnchantLevel(Enchantment.PROTECTION_ENVIRONMENTAL);
            if (current >= 5) {
                player.sendMessage(ChatColor.RED + "Максимальный уровень защиты достигнут!");
                return;
            }
            meta.addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, current + 1, true);
            clicked.setItemMeta(meta);
            // Обновляем броню
            switch (clicked.getType()) {
                case LEATHER_HELMET: case CHAINMAIL_HELMET: case IRON_HELMET: case DIAMOND_HELMET: player.getInventory().setHelmet(clicked); break;
                case LEATHER_CHESTPLATE: case CHAINMAIL_CHESTPLATE: case IRON_CHESTPLATE: case DIAMOND_CHESTPLATE: player.getInventory().setChestplate(clicked); break;
                case LEATHER_LEGGINGS: case CHAINMAIL_LEGGINGS: case IRON_LEGGINGS: case DIAMOND_LEGGINGS: player.getInventory().setLeggings(clicked); break;
                case LEATHER_BOOTS: case CHAINMAIL_BOOTS: case IRON_BOOTS: case DIAMOND_BOOTS: player.getInventory().setBoots(clicked); break;
            }
            profile.removeGold(cost);
            player.sendMessage(ChatColor.GREEN + "Защита увеличена до " + (current + 1));
        }

        player.closeInventory();
    }
}
