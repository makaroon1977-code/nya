package dev.yournick.mobarena.command;

import dev.yournick.mobarena.MobArenaPlugin;
import dev.yournick.mobarena.perk.Perk;
import dev.yournick.mobarena.player.PlayerProfile;
import dev.yournick.mobarena.perk.PlayerPerk;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class PerkSelectCommand implements CommandExecutor {

    private final MobArenaPlugin plugin;

    public PerkSelectCommand(MobArenaPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;
        openPerkGUI(player);
        return true;
    }

    public void openPerkGUI(Player player) {
        Inventory inv = Bukkit.createInventory(null, 9, "§6Выберите перк");

        PlayerProfile profile = plugin.getPlayerRepository().getProfile(player);
        if (profile == null) return;

        for (Perk perk : Perk.values()) {
            ItemStack item = new ItemStack(Material.PAPER);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(ChatColor.GREEN + perk.getDisplayName());

                List<String> lore = new ArrayList<>();
                switch (perk) {
                    case LUCKY:
                        lore.add(ChatColor.YELLOW + "+40% золота за убийство");
                        break;
                    case TOUGH:
                        lore.add(ChatColor.YELLOW + "Сопротивление I");
                        break;
                    case AGILE:
                        lore.add(ChatColor.YELLOW + "35% шанс уклонения + Скорость I");
                        break;
                    case FIREBORN:
                        lore.add(ChatColor.YELLOW + "Огнестойкость + Меч огня");
                        break;
                    case PIRATE:
                        lore.add(ChatColor.YELLOW + "Тошнота II + Сила II + Регенерация I");
                        break;
                }

                meta.setLore(lore);
                item.setItemMeta(meta);
            }
            inv.addItem(item);
        }

        player.openInventory(inv);
    }

    public void handleClick(InventoryClickEvent e) {
        if (!e.getView().getTitle().equals("§6Выберите перк")) return;

        e.setCancelled(true);

        if (!(e.getWhoClicked() instanceof Player)) return;
        Player player = (Player) e.getWhoClicked();

        PlayerProfile profile = plugin.getPlayerRepository().getProfile(player);
        if (profile == null) return;

        ItemStack clicked = e.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;

        String name = clicked.getItemMeta().getDisplayName();
        if (name == null) return;

        // Убираем цвета
        String strippedName = ChatColor.stripColor(name);

        for (Perk perk : Perk.values()) {
            if (perk.getDisplayName().equals(strippedName)) {
                // Сохраняем перк
                PlayerPerk playerPerk = profile.getPlayerPerk();
                if (playerPerk == null) {
                    playerPerk = new PlayerPerk(profile);
                }
                playerPerk.setPerk(perk);

                player.sendMessage(ChatColor.GREEN + "Вы выбрали перк: " + perk.getDisplayName());
                player.closeInventory();
                break;
            }
        }
    }
}
