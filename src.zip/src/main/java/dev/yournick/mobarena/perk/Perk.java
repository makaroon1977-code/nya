package dev.yournick.mobarena.perk;

import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.List;

public enum Perk {

    LUCKY("Удачливый", 1.4, 0, false),
    TOUGH("Стойкий", 1.0, 0, false),
    AGILE("Ловкий", 1.0, 0.35, false),
    FIREBORN("Огнерождённый", 1.0, 0, true),
    PIRATE("Пират", 1.0, 0, false);

    private final String displayName;
    private final double goldMultiplier;
    private final double dodgeChance;
    private final boolean fireEnchant;

    Perk(String displayName, double goldMultiplier, double dodgeChance, boolean fireEnchant) {
        this.displayName = displayName;
        this.goldMultiplier = goldMultiplier;
        this.dodgeChance = dodgeChance;
        this.fireEnchant = fireEnchant;
    }

    public String getDisplayName() { return displayName; }
    public double getGoldMultiplier() { return goldMultiplier; }
    public double getDodgeChance() { return dodgeChance; }
    public boolean isFireEnchant() { return fireEnchant; }

    public List<PotionEffect> getPermanentEffects() {
        List<PotionEffect> effects = new ArrayList<>();
        switch (this) {
            case TOUGH:
                effects.add(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, Integer.MAX_VALUE, 0, false, false));
                break;
            case AGILE:
                effects.add(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, false, false));
                break;
            case FIREBORN:
                effects.add(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false));
                break;
            case PIRATE:
                effects.add(new PotionEffect(PotionEffectType.CONFUSION, Integer.MAX_VALUE, 1, false, false));
                effects.add(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, Integer.MAX_VALUE, 1, false, false));
                effects.add(new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, 0, false, false));
                break;
        }
        return effects;
    }
}
