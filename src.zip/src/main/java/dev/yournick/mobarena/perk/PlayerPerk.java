package dev.yournick.mobarena.perk;

import dev.yournick.mobarena.player.PlayerProfile;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.potion.PotionEffect;

public class PlayerPerk {

    private Perk perk;
    private final PlayerProfile profile;

    public PlayerPerk(PlayerProfile profile) {
        this.profile = profile;
    }

    public Perk getPerk() {
        return perk;
    }

    public void setPerk(Perk perk) {
        this.perk = perk;
        applyEffects(profile.getPlayer());
    }

    public void applyEffects(Player player) {
        if (perk == null) return;

        // Снимаем старые эффекты
        player.getActivePotionEffects().forEach(pe -> player.removePotionEffect(pe.getType()));

        for (PotionEffect effect : perk.getPermanentEffects()) {
            player.addPotionEffect(effect);
        }

        // Ставим дополнительные свойства
        profile.setGoldMultiplier(perk.getGoldMultiplier());
        profile.setAgile(perk.getDodgeChance() > 0);
        profile.setFireborn(perk.isFireEnchant());
    }

    public boolean tryDodge() {
        if (perk == null) return false;
        return Math.random() < perk.getDodgeChance();
    }

    public int applyGoldBonus(int base) {
        if (perk == null) return base;
        return (int) (base * perk.getGoldMultiplier());
    }

    public boolean applyFireEnchant() {
        return perk != null && perk.isFireEnchant();
    }
}
