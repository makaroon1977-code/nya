package dev.yournick.mobarena.storage;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseManager {

    private final JavaPlugin plugin;
    private Connection connection;

    public DatabaseManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void init() {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                // SQLite — файл в папке плагина
                connection = DriverManager.getConnection(
                        "jdbc:sqlite:" + plugin.getDataFolder() + "/data.db"
                );

                // Создаём таблицу
                try (Statement st = connection.createStatement()) {
                    st.executeUpdate(
                            "CREATE TABLE IF NOT EXISTS player_data (" +
                                    "uuid TEXT PRIMARY KEY," +
                                    "gold INTEGER," +
                                    "best_wave INTEGER," +
                                    "bonus_health REAL," +
                                    "bonus_damage REAL," +
                                    "bonus_speed REAL" +
                                    ")"
                    );
                }

                Bukkit.getLogger().info("SQLite database initialized!");

            } catch (SQLException e) {
                e.printStackTrace();
            }
        });
    }

    public Connection getConnection() {
        return connection;
    }

    public void shutdown() {
        try {
            if (connection != null) connection.close();
        } catch (SQLException ignored) {}
    }
}
