package dev.yournick.mobarena.npc;

import dev.yournick.mobarena.MobArenaPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class NPCManager implements Listener {

    private final MobArenaPlugin plugin;
    private final Map<UUID, NPCType> npcMap = new HashMap<>();

    public enum NPCType {
        SHOP,
        UPGRADE
    }

    public NPCManager(MobArenaPlugin plugin) {
        this.plugin = plugin;

        Bukkit.getScheduler().runTask(plugin, this::spawnNPCs);
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    private void spawnNPCs() {
        spawnNPC(
                new Location(Bukkit.getWorld("world"), -120, 115, 283),
                "§aМагазин",
                NPCType.SHOP
        );

        spawnNPC(
                new Location(Bukkit.getWorld("world"), -120, 115, 276),
                "§bАпгрейды",
                NPCType.UPGRADE
        );
    }

    private void spawnNPC(Location loc, String name, NPCType type) {
        if (loc.getWorld() == null) return;

        Villager npc = (Villager) loc.getWorld().spawnEntity(loc, EntityType.VILLAGER);

        npc.setCustomName(name);
        npc.setCustomNameVisible(true);
        npc.setAI(false);
        npc.setInvulnerable(true);
        npc.setCollidable(false);
        npc.setSilent(true);
        npc.setRemoveWhenFarAway(false);

        // 🔒 ВАЖНО — убираем торговлю
        npc.setProfession(Villager.Profession.FARMER);

        npcMap.put(npc.getUniqueId(), type);
    }

    @EventHandler
    public void onNPCClick(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof Villager)) return;

        UUID id = event.getRightClicked().getUniqueId();
        if (!npcMap.containsKey(id)) return;

        // ⛔ ОТМЕНЯЕМ СРАЗУ
        event.setCancelled(true);

        Player player = event.getPlayer();
        NPCType type = npcMap.get(id);

        switch (type) {
            case SHOP:
                player.performCommand("arena_shop");
                break;

            case UPGRADE:
                player.performCommand("arena_upgrade");
                break;
        }
    }
}
