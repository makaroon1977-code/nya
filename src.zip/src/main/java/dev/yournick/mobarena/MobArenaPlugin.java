package dev.yournick.mobarena;

import dev.yournick.mobarena.arena.ArenaManager;
import dev.yournick.mobarena.command.ArenaCommand;
import dev.yournick.mobarena.command.ShopCommand;
import dev.yournick.mobarena.command.UpgradeCommand;
import dev.yournick.mobarena.command.PerkSelectCommand;
import dev.yournick.mobarena.listener.*;
import dev.yournick.mobarena.npc.NPCManager;
import dev.yournick.mobarena.player.PlayerRepository;
import org.bukkit.plugin.java.JavaPlugin;
import dev.yournick.mobarena.task.ActionBarTask;


public class MobArenaPlugin extends JavaPlugin {

    private static MobArenaPlugin instance;

    private ArenaManager arenaManager;
    private PlayerRepository playerRepository;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        // Репозиторий профилей игроков
        playerRepository = new PlayerRepository();

        // Менеджер арены
        arenaManager = new ArenaManager(this);

        // === Регистрация листенеров ===
        getServer().getPluginManager().registerEvents(new PlayerJoinQuitListener(playerRepository), this);
        getServer().getPluginManager().registerEvents(new MobDeathListener(arenaManager), this);
        getServer().getPluginManager().registerEvents(new MobDamageListener(arenaManager), this);

        // === Команды ===
        getCommand("arena").setExecutor(new ArenaCommand(arenaManager));
        getCommand("shop").setExecutor(new ShopCommand(this));
        getCommand("upgrade").setExecutor(new UpgradeCommand(this));

        // Команда апгрейдов
        UpgradeCommand upgradeCommand = new UpgradeCommand(this);
        getCommand("arena_upgrade").setExecutor(upgradeCommand);
        getServer().getPluginManager().registerEvents(new UpgradeListener(upgradeCommand), this);

        // Инициализация NPC
        new NPCManager(this);

        // Команда магазина
        ShopCommand shopCommand = new ShopCommand(this);
        getCommand("arena_shop").setExecutor(shopCommand);
        getServer().getPluginManager().registerEvents(new ShopListener(shopCommand), this);

        // === Команда выбора перка ===
        PerkSelectCommand perkCommand = new PerkSelectCommand(this);
        getCommand("perk").setExecutor(perkCommand);
        getServer().getPluginManager().registerEvents(new PerkListener(perkCommand), this);

        getLogger().info("MobArenaPlus enabled");
        new ActionBarTask(this).runTaskTimer(this, 20L, 20L);
    }

    @Override
    public void onDisable() {
        getLogger().info("MobArenaPlus disabled");
    }

    public static MobArenaPlugin getInstance() {
        return instance;
    }

    public PlayerRepository getPlayerRepository() {
        return playerRepository;
    }

    public ArenaManager getArenaManager() {
        return arenaManager;
    }
}
