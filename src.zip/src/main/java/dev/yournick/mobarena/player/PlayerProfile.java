package dev.yournick.mobarena.player;

import dev.yournick.mobarena.perk.PlayerPerk;
import org.bukkit.entity.Player;

import java.util.UUID;

public class PlayerProfile {

    private final UUID uuid;
    private final Player player;

    private PlayerPerk playerPerk;

    private int gold;
    private double bonusHealth;
    private double bonusSpeed;
    private int strengthLevel;

    // Перки: дополнительные свойства
    private double goldMultiplier = 1.0;
    private boolean agile = false;
    private boolean fireborn = false;

    public PlayerProfile(UUID uuid, Player player) {
        this.uuid = uuid;
        this.player = player;

        this.gold = 0;
        this.bonusHealth = 0;
        this.bonusSpeed = 0;
        this.strengthLevel = 0;

        this.playerPerk = new PlayerPerk(this);
    }

    public UUID getUuid() {
        return uuid;
    }

    public Player getPlayer() {
        return player;
    }

    // ===== Золото =====
    public int getGold() {
        int amount = gold;
        if (playerPerk != null) {
            amount = playerPerk.applyGoldBonus(amount);
        }
        return amount;
    }

    public void addGold(int amount) {
        if (playerPerk != null) {
            amount = playerPerk.applyGoldBonus(amount);
        }
        gold += amount;
    }

    public boolean removeGold(int amount) {
        if (gold < amount) return false;
        gold -= amount;
        return true;
    }

    // ===== Покупки =====
    public boolean buyHealthUpgrade(int cost, double value) {
        if (!removeGold(cost)) return false;
        bonusHealth += value;
        return true;
    }

    public boolean buySpeedUpgrade(int cost, double value) {
        if (!removeGold(cost)) return false;
        bonusSpeed += value;
        return true;
    }

    public boolean buyStrengthUpgrade(int cost) {
        if (!removeGold(cost)) return false;
        strengthLevel += 1;
        return true;
    }

    // ===== Бонусы =====
    public double getBonusHealth() {
        return bonusHealth;
    }

    public double getBonusSpeed() {
        return bonusSpeed;
    }

    public int getStrengthLevel() {
        return strengthLevel;
    }

    // ===== Перки =====
    public PlayerPerk getPlayerPerk() {
        if (playerPerk == null) {
            playerPerk = new PlayerPerk(this);
        }
        return playerPerk;
    }

    public double getGoldMultiplier() {
        return goldMultiplier;
    }

    public void setGoldMultiplier(double goldMultiplier) {
        this.goldMultiplier = goldMultiplier;
    }

    public boolean isAgile() {
        return agile;
    }

    public void setAgile(boolean agile) {
        this.agile = agile;
    }

    public boolean isFireborn() {
        return fireborn;
    }

    public void setFireborn(boolean fireborn) {
        this.fireborn = fireborn;
    }
}
