package dev.yournick.mobarena.mob;

public class MobStats {

    private final double health;
    private final double damage;
    private final double speed;

    public static MobStats forWave(int wave) {
        return new MobStats(
                20 + wave * 5,
                2 + wave * 0.6,
                Math.min(0.2 + wave * 0.01, 0.4)
        );
    }

    private MobStats(double health, double damage, double speed) {
        this.health = health;
        this.damage = damage;
        this.speed = speed;
    }

    public double getHealth() {
        return health;
    }

    public double getDamage() {
        return damage;
    }

    public double getSpeed() {
        return speed;
    }
}
